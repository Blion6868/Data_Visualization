```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import plotly.express as px

plt.rcParams['font.sans-serif'] = 'Helvetica'
```

Data courtesy of Kaggle: https://www.kaggle.com/datasets/drahulsingh/best-selling-books


```python
#load data

df = pd.read_csv(r"C:\Users\bryan\Desktop\books.csv")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Book</th>
      <th>Author(s)</th>
      <th>Original language</th>
      <th>First published</th>
      <th>Approximate sales in millions</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A Tale of Two Cities</td>
      <td>Charles Dickens</td>
      <td>English</td>
      <td>1859</td>
      <td>200.0</td>
      <td>Historical fiction</td>
    </tr>
    <tr>
      <th>1</th>
      <td>The Little Prince (Le Petit Prince)</td>
      <td>Antoine de Saint-Exupéry</td>
      <td>French</td>
      <td>1943</td>
      <td>200.0</td>
      <td>Novella</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Harry Potter and the Philosopher's Stone</td>
      <td>J. K. Rowling</td>
      <td>English</td>
      <td>1997</td>
      <td>120.0</td>
      <td>Fantasy</td>
    </tr>
    <tr>
      <th>3</th>
      <td>And Then There Were None</td>
      <td>Agatha Christie</td>
      <td>English</td>
      <td>1939</td>
      <td>100.0</td>
      <td>Mystery</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Dream of the Red Chamber (紅樓夢)</td>
      <td>Cao Xueqin</td>
      <td>Chinese</td>
      <td>1791</td>
      <td>100.0</td>
      <td>Family saga</td>
    </tr>
  </tbody>
</table>
</div>




```python
#see if there are any missing values

df.isnull().sum()
```




    Book                              0
    Author(s)                         0
    Original language                 0
    First published                   0
    Approximate sales in millions     0
    Genre                            56
    dtype: int64




```python
df.dropna(subset=['Genre'], inplace=True)
```


```python
df.isnull().sum()
```




    Book                             0
    Author(s)                        0
    Original language                0
    First published                  0
    Approximate sales in millions    0
    Genre                            0
    dtype: int64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>First published</th>
      <th>Approximate sales in millions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>118.000000</td>
      <td>118.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1961.483051</td>
      <td>38.765254</td>
    </tr>
    <tr>
      <th>std</th>
      <td>44.992636</td>
      <td>30.295672</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1788.000000</td>
      <td>10.400000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1945.000000</td>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1971.000000</td>
      <td>30.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1992.750000</td>
      <td>50.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2018.000000</td>
      <td>200.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (118, 6)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 118 entries, 0 to 145
    Data columns (total 6 columns):
     #   Column                         Non-Null Count  Dtype  
    ---  ------                         --------------  -----  
     0   Book                           118 non-null    object 
     1   Author(s)                      118 non-null    object 
     2   Original language              118 non-null    object 
     3   First published                118 non-null    int64  
     4   Approximate sales in millions  118 non-null    float64
     5   Genre                          118 non-null    object 
    dtypes: float64(1), int64(1), object(4)
    memory usage: 6.5+ KB
    


```python
titles = df.sort_values(by='Approximate sales in millions', ascending=False).head(10)
plt.figure(figsize=(10, 6))
plt.bar(titles['Book'], titles['Approximate sales in millions'])
plt.xticks(rotation=15, ha='right');
```


    
![png](output_9_0.png)
    



```python
#plot genre count

plt.figure(figsize=(18, 8))
sns.countplot(data=df, x='Genre')
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_10_0.png)
    



```python
df.groupby('Genre').mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>First published</th>
      <th>Approximate sales in millions</th>
    </tr>
    <tr>
      <th>Genre</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Adventure</th>
      <td>1887.0</td>
      <td>83.0</td>
    </tr>
    <tr>
      <th>Autobiographical novel</th>
      <td>1981.0</td>
      <td>18.0</td>
    </tr>
    <tr>
      <th>Autobiography</th>
      <td>1946.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>Bildungsroman, Historical fiction</th>
      <td>2003.0</td>
      <td>31.5</td>
    </tr>
    <tr>
      <th>Biographical novel</th>
      <td>1934.0</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Young Adult novel, adventure, war, science fiction, action thriller</th>
      <td>2010.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>Young adult fiction</th>
      <td>2008.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>Young adult historical novel</th>
      <td>1945.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>Young adult novel</th>
      <td>1982.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>Young adult romantic novel</th>
      <td>2012.0</td>
      <td>23.0</td>
    </tr>
  </tbody>
</table>
<p>80 rows × 2 columns</p>
</div>




```python
#determine the top 10 genres

top_genres = df['Genre'].value_counts().head(10)
top_genres = top_genres.sort_values(ascending=False) 

plt.figure(figsize=(18, 8))
sns.countplot(data=df[df['Genre'].isin(top_genres.index)], x='Genre', order=top_genres.index)
plt.xticks(rotation=15, ha='right')
plt.show()
```


    
![png](output_12_0.png)
    



```python
#determine titles for the Fantasy genre

df[df['Genre'] == 'Fantasy']['Book']
```




    2      Harry Potter and the Philosopher's Stone
    5                                    The Hobbit
    10      Harry Potter and the Chamber of Secrets
    11     Harry Potter and the Prisoner of Azkaban
    12          Harry Potter and the Goblet of Fire
    13    Harry Potter and the Order of the Phoenix
    14       Harry Potter and the Half-Blood Prince
    15         Harry Potter and the Deathly Hallows
    16                 The Alchemist (O Alquimista)
    29                               Watership Down
    Name: Book, dtype: object




```python
#determine titles for the novel genre

df[df['Genre'] == 'Novel']['Book']
```




    22                                    Lolita
    32                            The Ginger Man
    42                             Kane and Abel
    51                       Valley of the Dolls
    66                          Paul et Virginie
    70    Virgin Soil Upturned (Поднятая целина)
    74                                 The Shack
    86                        Things Fall Apart 
    Name: Book, dtype: object




```python
#Determine authors with the most books on the best seller list

top_authors = df['Author(s)'].value_counts().head(10)
top_authors = top_authors.sort_values(ascending=False) 

plt.figure(figsize=(18, 8))
sns.countplot(data=df[df['Author(s)'].isin(top_authors.index)], x='Author(s)', order=top_authors.index)
plt.xticks(rotation=15, ha='right')
plt.show()
```


    
![png](output_15_0.png)
    



```python
df.groupby('Author(s)').mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>First published</th>
      <th>Approximate sales in millions</th>
    </tr>
    <tr>
      <th>Author(s)</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Agatha Christie</th>
      <td>1939.0</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>Alexander Alexandrovich Fadeyev</th>
      <td>1945.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>Anna Sewell</th>
      <td>1877.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>Anne Frank</th>
      <td>1947.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>Anthony Doerr</th>
      <td>2014.0</td>
      <td>15.3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Wayne Dyer</th>
      <td>1976.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>William Bradford Huie</th>
      <td>1951.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>William P. Young</th>
      <td>2007.0</td>
      <td>22.5</td>
    </tr>
    <tr>
      <th>William Peter Blatty</th>
      <td>1971.0</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>Xaviera Hollander</th>
      <td>1971.0</td>
      <td>20.0</td>
    </tr>
  </tbody>
</table>
<p>104 rows × 2 columns</p>
</div>




```python
#determine titels for J.K. Rowling's books

df[df['Author(s)'] == 'J. K. Rowling']['Book']
```




    2      Harry Potter and the Philosopher's Stone
    10      Harry Potter and the Chamber of Secrets
    11     Harry Potter and the Prisoner of Azkaban
    12          Harry Potter and the Goblet of Fire
    13    Harry Potter and the Order of the Phoenix
    14       Harry Potter and the Half-Blood Prince
    15         Harry Potter and the Deathly Hallows
    Name: Book, dtype: object




```python
#Plot the sales in millions

plt.figure(figsize=(18, 8))
sns.histplot(data=df, x='Approximate sales in millions', bins=30, kde=True)
plt.show()
```


    
![png](output_18_0.png)
    



```python
plt.figure(figsize=(18, 8))
sns.boxplot(data=df, x="Approximate sales in millions", hue="Author(s)")
```




    <AxesSubplot:xlabel='Approximate sales in millions'>




    
![png](output_19_1.png)
    



```python
plt.figure(figsize=(18, 8))
sns.boxplot(data=df, x="Approximate sales in millions", hue="Book")
```




    <AxesSubplot:xlabel='Approximate sales in millions'>




    
![png](output_20_1.png)
    



```python
#determine outliers

df[df['Approximate sales in millions'] >= 100.0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Book</th>
      <th>Author(s)</th>
      <th>Original language</th>
      <th>First published</th>
      <th>Approximate sales in millions</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>A Tale of Two Cities</td>
      <td>Charles Dickens</td>
      <td>English</td>
      <td>1859</td>
      <td>200.0</td>
      <td>Historical fiction</td>
    </tr>
    <tr>
      <th>1</th>
      <td>The Little Prince (Le Petit Prince)</td>
      <td>Antoine de Saint-Exupéry</td>
      <td>French</td>
      <td>1943</td>
      <td>200.0</td>
      <td>Novella</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Harry Potter and the Philosopher's Stone</td>
      <td>J. K. Rowling</td>
      <td>English</td>
      <td>1997</td>
      <td>120.0</td>
      <td>Fantasy</td>
    </tr>
    <tr>
      <th>3</th>
      <td>And Then There Were None</td>
      <td>Agatha Christie</td>
      <td>English</td>
      <td>1939</td>
      <td>100.0</td>
      <td>Mystery</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Dream of the Red Chamber (紅樓夢)</td>
      <td>Cao Xueqin</td>
      <td>Chinese</td>
      <td>1791</td>
      <td>100.0</td>
      <td>Family saga</td>
    </tr>
    <tr>
      <th>5</th>
      <td>The Hobbit</td>
      <td>J. R. R. Tolkien</td>
      <td>English</td>
      <td>1937</td>
      <td>100.0</td>
      <td>Fantasy</td>
    </tr>
  </tbody>
</table>
</div>




```python
#determine the top 10 years with the most bestsellers

top_years = df['First published'].value_counts().head(10)
top_years = top_years.sort_values(ascending=False)

plt.figure(figsize=(18, 8))
sns.countplot(data=df[df['First published'].isin(top_years.index)], x='First published', order = top_years.index)
plt.xticks(rotation=0)
plt.show()
```


    
![png](output_22_0.png)
    



```python
#top language

top_language = df['Original language'].value_counts().head(10)
top_language = top_language.sort_values(ascending=False)

plt.figure(figsize=(18, 8))
sns.countplot(data=df[df['Original language'].isin(top_language.index)], x='Original language', order = top_language.index)
plt.xticks(rotation=0)
plt.show()
```


    
![png](output_23_0.png)
    



```python
#what are the bestseller titles in 1979?

df[df['First published'] == 1979]['Book']
```




    38                                  Flowers in the Attic
    42                                         Kane and Abel
    112    The Neverending Story (Die unendliche Geschichte)
    125                 The Hitchhiker's Guide to the Galaxy
    Name: Book, dtype: object




```python
#what are the bestseller titles in 1988?

df[df['First published'] == 1988]['Book']
```




    16     The Alchemist (O Alquimista)
    65          A Brief History of Time
    80                   Kitchen (キッチン)
    108                         Matilda
    Name: Book, dtype: object




```python
years_to_select = [1988, 2012, 1992, 1974, 2000]
df[df['First published'].isin(years_to_select)]['Book']
```




    8      Vardi Wala Gunda (वर्दी वाला गुंडा)
    12     Harry Potter and the Goblet of Fire
    16            The Alchemist (O Alquimista)
    18           The Bridges of Madison County
    41                         Angels & Demons
    65                 A Brief History of Time
    72                  The Fault in Our Stars
    80                          Kitchen (キッチン)
    83                               Gone Girl
    90                                    Jaws
    108                                Matilda
    145                    Fifty Shades Darker
    Name: Book, dtype: object




```python
#most popular genres in 1979

df[df['First published'] == 1979]['Genre']
```




    38     Gothic horror, Family saga
    42                          Novel
    112         Children's Literature
    125               Science fiction
    Name: Genre, dtype: object




```python
#most popular genres in 1988

df[df['First published'] == 1988]['Genre']
```




    16                   Fantasy
    65           Popular science
    80            Japanese novel
    108    Children's Literature
    Name: Genre, dtype: object




```python
#most popular genres in 1952

df[df['First published'] == 1952]['Genre']
```




    31     Children's fiction
    100             Self-help
    Name: Genre, dtype: object




```python
fig=px.sunburst(df,path=['Original language', 'Genre','Author(s)'],values='Approximate sales in millions',color='Approximate sales in millions',height=800,width=1000,title="Approximate sales of Books in millions")
fig.update_layout(title_pad_l=330)
fig.show();
```


<div>                            <div id="58815c61-9b84-4a61-ac5b-8d24b5b7234f" class="plotly-graph-div" style="height:800px; width:1000px;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("58815c61-9b84-4a61-ac5b-8d24b5b7234f")) {                    Plotly.newPlot(                        "58815c61-9b84-4a61-ac5b-8d24b5b7234f",                        [{"branchvalues":"total","customdata":[[100.0],[26.0],[50.0],[35.0],[15.3],[200.0],[20.0],[20.0],[45.0],[50.0],[30.0],[85.0],[100.0],[40.0],[35.0],[200.0],[20.0],[33.0],[30.0],[30.0],[80.0],[39.0],[30.0],[18.0],[20.0],[14.0],[50.0],[13.249999999999998],[40.0],[43.0],[20.0],[20.0],[21.0],[30.0],[20.0],[50.0],[30.0],[20.0],[20.0],[83.0],[40.0],[25.0],[20.0],[65.0],[79.41379310344827],[50.0],[100.0],[50.0],[31.0],[25.0],[23.0],[20.0],[20.0],[37.0],[20.0],[50.0],[23.0],[40.0],[15.0],[25.0],[31.5],[36.0],[50.0],[12.0],[50.0],[50.0],[30.0],[16.0],[20.0],[21.0],[20.0],[16.0],[20.0],[16.0],[24.0],[36.4],[20.0],[20.0],[23.0],[65.0],[20.0],[20.0],[50.0],[44.0],[33.0],[17.0],[20.0],[28.0],[60.0],[20.0],[21.0],[50.0],[29.0],[25.0],[25.0],[30.0],[20.0],[21.0],[20.0],[29.0],[18.0],[20.0],[50.0],[40.0],[80.0],[50.0],[35.0],[30.0],[22.5],[11.0],[20.0],[83.0],[18.0],[20.0],[31.5],[25.0],[32.94871794871795],[16.0],[43.0],[21.0],[20.0],[50.0],[50.0],[41.666666666666664],[20.0],[42.1025641025641],[20.0],[33.0],[20.0],[65.0],[18.0],[21.0],[20.0],[80.0],[12.0],[30.0],[13.249999999999998],[40.0],[100.0],[80.28869047619048],[65.0],[85.0],[35.0],[20.0],[30.0],[30.0],[40.0],[30.0],[147.88135593220338],[15.3],[35.0],[36.0],[50.0],[11.0],[20.0],[50.0],[50.0],[20.0],[100.0],[80.0],[39.0],[23.0],[39.1270783847981],[25.0],[24.0],[30.0],[200.0],[44.0],[40.0],[20.0],[25.0],[40.0],[20.0],[60.0],[21.0],[33.0],[20.0],[20.0],[14.0],[20.0],[20.0],[33.095238095238095],[29.0],[20.0],[50.0],[20.0],[36.4],[40.0],[21.6046511627907],[20.0],[20.0],[20.0],[50.0],[16.0],[21.0],[20.0],[29.0],[26.0],[20.0],[23.0],[86.66666666666667],[20.0],[35.0],[58.14172266864938],[180.55555555555554],[36.69767441860465],[68.0],[43.8235294117647],[19.05263157894737],[33.333333333333336],[65.0],[28.84920440636475],[50.0],[30.0]],"domain":{"x":[0.0,1.0],"y":[0.0,1.0]},"hovertemplate":"labels=%{label}<br>Approximate sales in millions_sum=%{value}<br>parent=%{parent}<br>id=%{id}<br>Approximate sales in millions=%{color}<extra></extra>","ids":["English/Mystery/Agatha Christie","Russian/Young adult historical novel/Alexander Alexandrovich Fadeyev","English/Children's literature/Anna Sewell","Dutch/Historical non-fiction, Autobiography, Memoir, Bildungsroman / Coming of Age, Jewish literature/Anne Frank","English/Historical fiction, war novel/Anthony Doerr","French/Novella/Antoine de Saint-Exup\u00e9ry","English/Pregnancy guide/Arlene Eisenberg and Heidi Murkoff","Japanese/Japanese novel/Banana Yoshimoto","English/Children's Literature/Beatrix Potter","English/Manual/Benjamin Spock","English/Self-help/Bill Wilson","English/Fantasy, Children's fiction/C. S. Lewis","Chinese/Family saga/Cao Xueqin","English/Popular science, Anthropology, Astrophysics, Cosmology, Philosophy, History/Carl Sagan","Italian/Fantasy, Children's fiction/Carlo Collodi","English/Historical fiction/Charles Dickens","English/Novel/Chinua Achebe","English/Romantic family saga/Colleen McCullough","English/Self-help/Dale Carnegie","English/Fiction/Dan Brown","English/Mystery thriller/Dan Brown","English/Mystery-thriller/Dan Brown","English/Gothic novel/Daphne du Maurier","English/Coming-of-age Murder mystery/Delia Owens","English/Social Science, Anthropology, Psychology/Desmond Morris","English/Science fiction/Douglas Adams","English/Children's fiction/E. B. White; illustrated by Garth Williams","English/Erotica/E. L. James","English/Essay/Literature/Elbert Hubbard","English/Children's Literature, picture book/Eric Carle","English/Romantic novel/Erica Jong","German/War novel/Erich Maria Remarque","English/Romance novel/Erich Segal","English/Novel, tragedy/F. Scott Fitzgerald","English/Science fiction novel/Frank Herbert","Spanish/Magic realism/Gabriel Garc\u00eda M\u00e1rquez","English/Dystopian, political fiction, social science fiction/George Orwell","English/Satirical allegorical novella, Political satire, Dystopian Fiction, Roman \u00e0 clef/George Orwell","English/Crime thriller novel/Gillian Flynn","English/Adventure/H. Rider Haggard","English/Southern Gothic, Bildungsroman/Harper Lee","English/Biographical novel/Irving Stone","Russian/Science fiction novel/Ivan Yefremov","English/Coming-of-age/J. D. Salinger","English/Fantasy/J. K. Rowling","English/Novel/J. P. Donleavy","English/Fantasy/J. R. R. Tolkien","English/War, thriller/Jack Higgins","English/Novel/Jacqueline Susann","French/Novel/Jacques-Henri Bernardin de Saint-Pierre","English/New-age spiritual novel/James Redfield","English/Classic regency novel, romance/Jane Austen","Czech/Unfinished satirical dark comedy novel/Jaroslav Ha\u0161ek","English/Novel/Jeffrey Archer","Chinese/Semi-autobiographical novel/Jiang Rong","German/Children's fiction/Johanna Spyri","English/Young adult romantic novel/John Green","Norwegian/Philosophical novel, Young adult/Jostein Gaarder","English/Historical fiction/Ken Follett","English/Children's literature/Kenneth Grahame","English/Bildungsroman, Historical fiction/Khaled Hosseini","Russian/Historical novel/Leo Tolstoy","English/Historical fiction/Lew Wallace","English/Dystopian fiction/Lois Lowry","English/Self-help/Louise Hay","English/Children's novel/Lucy Maud Montgomery","English/Historical fiction/Margaret Mitchell","English/Children's Literature/Margaret Wise Brown","English/Feminist novel/Marilyn French","English/Crime novel/Mario Puzo","English/Picaresque novel, Bildungsroman, satire, Robinsonade/Mark Twain","English/Young Adult Fiction/Markus Zusak","English/Children's picture book/Maurice Sendak","German/Children's Literature/Michael Ende","Russian/Novel/Mikhail Sholokhov","Russian/Socialist realist novel/Nikolai Ostrovsky","English/Self-help/Norman Vincent Peale","Hindi/Autobiography/Paramahansa Yogananda","English/Thriller/Paula Hawkins","Portuguese/Fantasy/Paulo Coelho","English/Thriller/Peter Benchley","English/Self-help/Rhonda Byrne","English/Fantasy/Richard Adams","English/Novella, Self-help/Richard Bach","English/Christian literature/Rick Warren","English/Children's Literature/Roald Dahl","English/Children's fantasy novel/Roald Dahl","English/Children's novel/Roald Dahl","English/Romance/Robert James Waller","English/Children's literature, picture book, fiction/Robert Munsch","Russian/Children's Literature, picture book/Sergey Mikhalkov","English/Sexology/Shere Hite","English/Self-help, motivational, business fable, psychology, leadership, parable/Spencer Johnson","English/Popular science/Stephen Hawking","English/Self-help/Stephen R. Covey","Swedish/Fiction/Stieg Larsson","English/Young adult novel/Sue Townsend","English/Young Adult novel, adventure, dystopian, science fiction/Suzanne Collins","English/Young Adult novel, adventure, war, science fiction, action thriller/Suzanne Collins","English/Young adult fiction/Suzanne Collins","Japanese/Autobiographical novel/Tetsuko Kuroyanagi","Norwegian/Travel literature/Thor Heyerdahl","Italian/Historical novel, mystery/Umberto Eco","English/Gothic horror, Family saga/V. C. Andrews","Hindi/Detective/Ved Prakash Sharma","English/Novel/Vladimir Nabokov","English/Self-help/Wayne Dyer","English/Fiction/William Bradford Huie","English/Novel/William P. Young","English/Horror/William Peter Blatty","English/Memoir/Xaviera Hollander","English/Adventure","Japanese/Autobiographical novel","Hindi/Autobiography","English/Bildungsroman, Historical fiction","English/Biographical novel","English/Children's Literature","German/Children's Literature","English/Children's Literature, picture book","Russian/Children's Literature, picture book","English/Children's fantasy novel","English/Children's fiction","German/Children's fiction","English/Children's literature","English/Children's literature, picture book, fiction","English/Children's novel","English/Children's picture book","English/Christian literature","English/Classic regency novel, romance","English/Coming-of-age","English/Coming-of-age Murder mystery","English/Crime novel","English/Crime thriller novel","Hindi/Detective","English/Dystopian fiction","English/Dystopian, political fiction, social science fiction","English/Erotica","English/Essay/Literature","Chinese/Family saga","English/Fantasy","Portuguese/Fantasy","English/Fantasy, Children's fiction","Italian/Fantasy, Children's fiction","English/Feminist novel","English/Fiction","Swedish/Fiction","English/Gothic horror, Family saga","English/Gothic novel","English/Historical fiction","English/Historical fiction, war novel","Dutch/Historical non-fiction, Autobiography, Memoir, Bildungsroman / Coming of Age, Jewish literature","Russian/Historical novel","Italian/Historical novel, mystery","English/Horror","Japanese/Japanese novel","Spanish/Magic realism","English/Manual","English/Memoir","English/Mystery","English/Mystery thriller","English/Mystery-thriller","English/New-age spiritual novel","English/Novel","French/Novel","Russian/Novel","English/Novel, tragedy","French/Novella","English/Novella, Self-help","Norwegian/Philosophical novel, Young adult","English/Picaresque novel, Bildungsroman, satire, Robinsonade","English/Popular science","English/Popular science, Anthropology, Astrophysics, Cosmology, Philosophy, History","English/Pregnancy guide","English/Romance","English/Romance novel","English/Romantic family saga","English/Romantic novel","English/Satirical allegorical novella, Political satire, Dystopian Fiction, Roman \u00e0 clef","English/Science fiction","English/Science fiction novel","Russian/Science fiction novel","English/Self-help","English/Self-help, motivational, business fable, psychology, leadership, parable","Chinese/Semi-autobiographical novel","English/Sexology","English/Social Science, Anthropology, Psychology","Russian/Socialist realist novel","English/Southern Gothic, Bildungsroman","English/Thriller","Norwegian/Travel literature","Czech/Unfinished satirical dark comedy novel","German/War novel","English/War, thriller","English/Young Adult Fiction","English/Young Adult novel, adventure, dystopian, science fiction","English/Young Adult novel, adventure, war, science fiction, action thriller","English/Young adult fiction","Russian/Young adult historical novel","English/Young adult novel","English/Young adult romantic novel","Chinese","Czech","Dutch","English","French","German","Hindi","Italian","Japanese","Norwegian","Portuguese","Russian","Spanish","Swedish"],"labels":["Agatha Christie","Alexander Alexandrovich Fadeyev","Anna Sewell","Anne Frank","Anthony Doerr","Antoine de Saint-Exup\u00e9ry","Arlene Eisenberg and Heidi Murkoff","Banana Yoshimoto","Beatrix Potter","Benjamin Spock","Bill Wilson","C. S. Lewis","Cao Xueqin","Carl Sagan","Carlo Collodi","Charles Dickens","Chinua Achebe","Colleen McCullough","Dale Carnegie","Dan Brown","Dan Brown","Dan Brown","Daphne du Maurier","Delia Owens","Desmond Morris","Douglas Adams","E. B. White; illustrated by Garth Williams","E. L. James","Elbert Hubbard","Eric Carle","Erica Jong","Erich Maria Remarque","Erich Segal","F. Scott Fitzgerald","Frank Herbert","Gabriel Garc\u00eda M\u00e1rquez","George Orwell","George Orwell","Gillian Flynn","H. Rider Haggard","Harper Lee","Irving Stone","Ivan Yefremov","J. D. Salinger","J. K. Rowling","J. P. Donleavy","J. R. R. Tolkien","Jack Higgins","Jacqueline Susann","Jacques-Henri Bernardin de Saint-Pierre","James Redfield","Jane Austen","Jaroslav Ha\u0161ek","Jeffrey Archer","Jiang Rong","Johanna Spyri","John Green","Jostein Gaarder","Ken Follett","Kenneth Grahame","Khaled Hosseini","Leo Tolstoy","Lew Wallace","Lois Lowry","Louise Hay","Lucy Maud Montgomery","Margaret Mitchell","Margaret Wise Brown","Marilyn French","Mario Puzo","Mark Twain","Markus Zusak","Maurice Sendak","Michael Ende","Mikhail Sholokhov","Nikolai Ostrovsky","Norman Vincent Peale","Paramahansa Yogananda","Paula Hawkins","Paulo Coelho","Peter Benchley","Rhonda Byrne","Richard Adams","Richard Bach","Rick Warren","Roald Dahl","Roald Dahl","Roald Dahl","Robert James Waller","Robert Munsch","Sergey Mikhalkov","Shere Hite","Spencer Johnson","Stephen Hawking","Stephen R. Covey","Stieg Larsson","Sue Townsend","Suzanne Collins","Suzanne Collins","Suzanne Collins","Tetsuko Kuroyanagi","Thor Heyerdahl","Umberto Eco","V. C. Andrews","Ved Prakash Sharma","Vladimir Nabokov","Wayne Dyer","William Bradford Huie","William P. Young","William Peter Blatty","Xaviera Hollander","Adventure","Autobiographical novel","Autobiography","Bildungsroman, Historical fiction","Biographical novel","Children's Literature","Children's Literature","Children's Literature, picture book","Children's Literature, picture book","Children's fantasy novel","Children's fiction","Children's fiction","Children's literature","Children's literature, picture book, fiction","Children's novel","Children's picture book","Christian literature","Classic regency novel, romance","Coming-of-age","Coming-of-age Murder mystery","Crime novel","Crime thriller novel","Detective","Dystopian fiction","Dystopian, political fiction, social science fiction","Erotica","Essay/Literature","Family saga","Fantasy","Fantasy","Fantasy, Children's fiction","Fantasy, Children's fiction","Feminist novel","Fiction","Fiction","Gothic horror, Family saga","Gothic novel","Historical fiction","Historical fiction, war novel","Historical non-fiction, Autobiography, Memoir, Bildungsroman / Coming of Age, Jewish literature","Historical novel","Historical novel, mystery","Horror","Japanese novel","Magic realism","Manual","Memoir","Mystery","Mystery thriller","Mystery-thriller","New-age spiritual novel","Novel","Novel","Novel","Novel, tragedy","Novella","Novella, Self-help","Philosophical novel, Young adult","Picaresque novel, Bildungsroman, satire, Robinsonade","Popular science","Popular science, Anthropology, Astrophysics, Cosmology, Philosophy, History","Pregnancy guide","Romance","Romance novel","Romantic family saga","Romantic novel","Satirical allegorical novella, Political satire, Dystopian Fiction, Roman \u00e0 clef","Science fiction","Science fiction novel","Science fiction novel","Self-help","Self-help, motivational, business fable, psychology, leadership, parable","Semi-autobiographical novel","Sexology","Social Science, Anthropology, Psychology","Socialist realist novel","Southern Gothic, Bildungsroman","Thriller","Travel literature","Unfinished satirical dark comedy novel","War novel","War, thriller","Young Adult Fiction","Young Adult novel, adventure, dystopian, science fiction","Young Adult novel, adventure, war, science fiction, action thriller","Young adult fiction","Young adult historical novel","Young adult novel","Young adult romantic novel","Chinese","Czech","Dutch","English","French","German","Hindi","Italian","Japanese","Norwegian","Portuguese","Russian","Spanish","Swedish"],"marker":{"coloraxis":"coloraxis","colors":[100.0,26.0,50.0,35.0,15.3,200.0,20.0,20.0,45.0,50.0,30.0,85.0,100.0,40.0,35.0,200.0,20.0,33.0,30.0,30.0,80.0,39.0,30.0,18.0,20.0,14.0,50.0,13.249999999999998,40.0,43.0,20.0,20.0,21.0,30.0,20.0,50.0,30.0,20.0,20.0,83.0,40.0,25.0,20.0,65.0,79.41379310344827,50.0,100.0,50.0,31.0,25.0,23.0,20.0,20.0,37.0,20.0,50.0,23.0,40.0,15.0,25.0,31.5,36.0,50.0,12.0,50.0,50.0,30.0,16.0,20.0,21.0,20.0,16.0,20.0,16.0,24.0,36.4,20.0,20.0,23.0,65.0,20.0,20.0,50.0,44.0,33.0,17.0,20.0,28.0,60.0,20.0,21.0,50.0,29.0,25.0,25.0,30.0,20.0,21.0,20.0,29.0,18.0,20.0,50.0,40.0,80.0,50.0,35.0,30.0,22.5,11.0,20.0,83.0,18.0,20.0,31.5,25.0,32.94871794871795,16.0,43.0,21.0,20.0,50.0,50.0,41.666666666666664,20.0,42.1025641025641,20.0,33.0,20.0,65.0,18.0,21.0,20.0,80.0,12.0,30.0,13.249999999999998,40.0,100.0,80.28869047619048,65.0,85.0,35.0,20.0,30.0,30.0,40.0,30.0,147.88135593220338,15.3,35.0,36.0,50.0,11.0,20.0,50.0,50.0,20.0,100.0,80.0,39.0,23.0,39.1270783847981,25.0,24.0,30.0,200.0,44.0,40.0,20.0,25.0,40.0,20.0,60.0,21.0,33.0,20.0,20.0,14.0,20.0,20.0,33.095238095238095,29.0,20.0,50.0,20.0,36.4,40.0,21.6046511627907,20.0,20.0,20.0,50.0,16.0,21.0,20.0,29.0,26.0,20.0,23.0,86.66666666666667,20.0,35.0,58.14172266864938,180.55555555555554,36.69767441860465,68.0,43.8235294117647,19.05263157894737,33.333333333333336,65.0,28.84920440636475,50.0,30.0]},"name":"","parents":["English/Mystery","Russian/Young adult historical novel","English/Children's literature","Dutch/Historical non-fiction, Autobiography, Memoir, Bildungsroman / Coming of Age, Jewish literature","English/Historical fiction, war novel","French/Novella","English/Pregnancy guide","Japanese/Japanese novel","English/Children's Literature","English/Manual","English/Self-help","English/Fantasy, Children's fiction","Chinese/Family saga","English/Popular science, Anthropology, Astrophysics, Cosmology, Philosophy, History","Italian/Fantasy, Children's fiction","English/Historical fiction","English/Novel","English/Romantic family saga","English/Self-help","English/Fiction","English/Mystery thriller","English/Mystery-thriller","English/Gothic novel","English/Coming-of-age Murder mystery","English/Social Science, Anthropology, Psychology","English/Science fiction","English/Children's fiction","English/Erotica","English/Essay/Literature","English/Children's Literature, picture book","English/Romantic novel","German/War novel","English/Romance novel","English/Novel, tragedy","English/Science fiction novel","Spanish/Magic realism","English/Dystopian, political fiction, social science fiction","English/Satirical allegorical novella, Political satire, Dystopian Fiction, Roman \u00e0 clef","English/Crime thriller novel","English/Adventure","English/Southern Gothic, Bildungsroman","English/Biographical novel","Russian/Science fiction novel","English/Coming-of-age","English/Fantasy","English/Novel","English/Fantasy","English/War, thriller","English/Novel","French/Novel","English/New-age spiritual novel","English/Classic regency novel, romance","Czech/Unfinished satirical dark comedy novel","English/Novel","Chinese/Semi-autobiographical novel","German/Children's fiction","English/Young adult romantic novel","Norwegian/Philosophical novel, Young adult","English/Historical fiction","English/Children's literature","English/Bildungsroman, Historical fiction","Russian/Historical novel","English/Historical fiction","English/Dystopian fiction","English/Self-help","English/Children's novel","English/Historical fiction","English/Children's Literature","English/Feminist novel","English/Crime novel","English/Picaresque novel, Bildungsroman, satire, Robinsonade","English/Young Adult Fiction","English/Children's picture book","German/Children's Literature","Russian/Novel","Russian/Socialist realist novel","English/Self-help","Hindi/Autobiography","English/Thriller","Portuguese/Fantasy","English/Thriller","English/Self-help","English/Fantasy","English/Novella, Self-help","English/Christian literature","English/Children's Literature","English/Children's fantasy novel","English/Children's novel","English/Romance","English/Children's literature, picture book, fiction","Russian/Children's Literature, picture book","English/Sexology","English/Self-help, motivational, business fable, psychology, leadership, parable","English/Popular science","English/Self-help","Swedish/Fiction","English/Young adult novel","English/Young Adult novel, adventure, dystopian, science fiction","English/Young Adult novel, adventure, war, science fiction, action thriller","English/Young adult fiction","Japanese/Autobiographical novel","Norwegian/Travel literature","Italian/Historical novel, mystery","English/Gothic horror, Family saga","Hindi/Detective","English/Novel","English/Self-help","English/Fiction","English/Novel","English/Horror","English/Memoir","English","Japanese","Hindi","English","English","English","German","English","Russian","English","English","German","English","English","English","English","English","English","English","English","English","English","Hindi","English","English","English","English","Chinese","English","Portuguese","English","Italian","English","English","Swedish","English","English","English","English","Dutch","Russian","Italian","English","Japanese","Spanish","English","English","English","English","English","English","English","French","Russian","English","French","English","Norwegian","English","English","English","English","English","English","English","English","English","English","English","Russian","English","English","Chinese","English","English","Russian","English","English","Norwegian","Czech","German","English","English","English","English","English","Russian","English","English","","","","","","","","","","","","","",""],"values":[100.0,26.0,50.0,35.0,15.3,200.0,20.0,20.0,45.0,50.0,30.0,85.0,100.0,40.0,35.0,200.0,20.0,33.0,30.0,30.0,80.0,39.0,30.0,18.0,20.0,14.0,50.0,25.6,40.0,43.0,20.0,20.0,21.0,30.0,20.0,50.0,30.0,20.0,20.0,83.0,40.0,25.0,20.0,65.0,522.0,50.0,100.0,50.0,31.0,25.0,23.0,20.0,20.0,37.0,20.0,50.0,23.0,40.0,15.0,25.0,31.5,36.0,50.0,12.0,50.0,50.0,30.0,16.0,20.0,21.0,20.0,16.0,20.0,16.0,24.0,36.4,20.0,20.0,23.0,65.0,20.0,20.0,50.0,44.0,33.0,17.0,20.0,28.0,60.0,20.0,21.0,50.0,29.0,25.0,25.0,30.0,20.0,21.0,20.0,29.0,18.0,20.0,50.0,40.0,80.0,50.0,35.0,30.0,22.5,11.0,20.0,83.0,18.0,20.0,31.5,25.0,78.0,16.0,43.0,21.0,20.0,50.0,50.0,75.0,20.0,78.0,20.0,33.0,20.0,65.0,18.0,21.0,20.0,80.0,12.0,30.0,25.6,40.0,100.0,672.0,65.0,85.0,35.0,20.0,60.0,30.0,40.0,30.0,295.0,15.3,35.0,36.0,50.0,11.0,20.0,50.0,50.0,20.0,100.0,80.0,39.0,23.0,210.5,25.0,24.0,30.0,200.0,44.0,40.0,20.0,25.0,40.0,20.0,60.0,21.0,33.0,20.0,20.0,14.0,20.0,20.0,210.0,29.0,20.0,50.0,20.0,36.4,40.0,43.0,20.0,20.0,20.0,50.0,16.0,21.0,20.0,29.0,26.0,20.0,23.0,120.0,20.0,35.0,3496.9,225.0,86.0,100.0,85.0,38.0,60.0,65.0,163.4,50.0,30.0],"type":"sunburst"}],                        {"template":{"data":{"histogram2dcontour":[{"type":"histogram2dcontour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"choropleth":[{"type":"choropleth","colorbar":{"outlinewidth":0,"ticks":""}}],"histogram2d":[{"type":"histogram2d","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmap":[{"type":"heatmap","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"heatmapgl":[{"type":"heatmapgl","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"contourcarpet":[{"type":"contourcarpet","colorbar":{"outlinewidth":0,"ticks":""}}],"contour":[{"type":"contour","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"surface":[{"type":"surface","colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]}],"mesh3d":[{"type":"mesh3d","colorbar":{"outlinewidth":0,"ticks":""}}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"parcoords":[{"type":"parcoords","line":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolargl":[{"type":"scatterpolargl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"scattergeo":[{"type":"scattergeo","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterpolar":[{"type":"scatterpolar","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"scattergl":[{"type":"scattergl","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatter3d":[{"type":"scatter3d","line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattermapbox":[{"type":"scattermapbox","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scatterternary":[{"type":"scatterternary","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"scattercarpet":[{"type":"scattercarpet","marker":{"colorbar":{"outlinewidth":0,"ticks":""}}}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}],"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"pie":[{"automargin":true,"type":"pie"}]},"layout":{"autotypenumbers":"strict","colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"hovermode":"closest","hoverlabel":{"align":"left"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"bgcolor":"#E5ECF6","angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"ternary":{"bgcolor":"#E5ECF6","aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]]},"xaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"yaxis":{"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","automargin":true,"zerolinewidth":2},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white","gridwidth":2}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"geo":{"bgcolor":"white","landcolor":"#E5ECF6","subunitcolor":"white","showland":true,"showlakes":true,"lakecolor":"white"},"title":{"x":0.05},"mapbox":{"style":"light"}}},"coloraxis":{"colorbar":{"title":{"text":"Approximate sales in millions"}},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"legend":{"tracegroupgap":0},"title":{"text":"Approximate sales of Books in millions","pad":{"l":330}},"height":800,"width":1000},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('58815c61-9b84-4a61-ac5b-8d24b5b7234f');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


# Findings

1. the most popular genre is Fantasy
2. The most popular language is English
3. The most lucrative year for bestsellers was 1979
4. J.K. Rowling has the most sales as a single author

# Assertions to Test

1. 6 books with over 100 million in sales may be skewing the data
2. Fantasy may be overrepresented due to the popularity of Rowling's Harry Potter series and The Hobbit


```python
df2 = df.drop(df[df['Author(s)'] == 'J.K. Rowling'].index)
```


```python
df2 = df.drop(df[df['Book'].str.contains('Potter')].index)
```


```python
#after removing Harry Potter, what is the most represented genre in terms of bestsellers?

top_genres = df2['Genre'].value_counts().head(10)
top_genres = top_genres.sort_values(ascending=False) 

plt.figure(figsize=(18, 8))
sns.countplot(data=df2[df2['Genre'].isin(top_genres.index)], x='Genre', order=top_genres.index)
plt.xticks(rotation=15, ha='right')
plt.show()
```


    
![png](output_37_0.png)
    



```python
#let's remove authors with over 100 million sales from the dataset to see if Fantasy remains the best represented genre amongst bestsellers

df3 = df.drop(df[df['Author(s)'] == 'J.K. Rowling'].index)
df3 = df.drop(df[df['Author(s)'] == 'Charles Dickens'].index)
df3 = df.drop(df[df['Author(s)'] == 'Antoine de Saint-Exupéry'].index)
df3 = df.drop(df[df['Author(s)'] == 'Agatha Christie'].index)
df3 = df.drop(df[df['Author(s)'] == 'Cao Xueqin'].index)
df3 = df.drop(df[df['Author(s)'] == 'J. R. R. Tolkien'].index)
```


```python
df3 = df.drop(df[df['Book'].str.contains('Potter')].index)
df3 = df.drop(df[df['Book'] == 'A Tale of Two Cities'].index)
df3 = df.drop(df[df['Book'] == 'The Hobbt'].index)
df3 = df.drop(df[df['Book'] == 'Dream of the Red Chamber (紅樓夢)'].index)
df3 = df.drop(df[df['Book'] == 'The Little Prince (Le Petit Prince)'].index)
df3 = df.drop(df[df['Book'] == 'And Then There Were'].index)
```


```python
#after removing Harry Potter, what is the most represented genre in terms of bestsellers?

top_genres = df3['Genre'].value_counts().head(10)
top_genres = top_genres.sort_values(ascending=False) 

plt.figure(figsize=(18, 8))
sns.countplot(data=df3[df3['Genre'].isin(top_genres.index)], x='Genre', order=top_genres.index)
plt.xticks(rotation=15, ha='right')
plt.show()
```


    
![png](output_40_0.png)
    


Conclusion: Removing Harry Potter shows that fantasy may be overrepresented, with Novel being the most popular genre; however, removing all books with over 100 million in sales shows that fantasy still remains the most lucrative genre for bestsellers.


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
